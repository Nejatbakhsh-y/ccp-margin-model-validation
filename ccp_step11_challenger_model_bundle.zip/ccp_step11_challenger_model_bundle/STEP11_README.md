# Step 11 — Challenger Model

This bundle contains:

- `src/ccp_margin/models/challenger/parametric_var.py`
- `src/ccp_margin/models/challenger/ewma_covariance.py`
- `src/ccp_margin/models/challenger/correlation_controls.py`
- `src/ccp_margin/models/challenger/__init__.py`
- `tests/test_challenger_model.py`

The implementation includes:

- Variance-covariance VaR using current signed market-value exposures.
- Equally weighted sample covariance and EWMA covariance.
- PSD covariance repair through correlation-space eigenvalue clipping.
- Square-root-of-time and directly estimated compounded multi-day returns.
- Normal VaR and standardized Student-t sensitivity VaR.
- Correlation stress sensitivity.
- Component VaR attribution and diversification-benefit diagnostics.
- Missing-risk-factor controls.
- Lookback-window sensitivity.
- Deterministic results.

From the project root, run:

```powershell
python -m pip install -e .
python -m pytest tests\test_challenger_model.py -q
python -m pytest -q
python -m ruff check src\ccp_margin\models\challenger tests\test_challenger_model.py
```
